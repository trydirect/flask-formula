# Flask Api Template README #


How to upgrade template application
===================================

1. Compress backend directory into flask_app.tar.gz
cd flask_formula/v01 
tar -pcvzf flask_app.tar.gz backend
2. Copy archive into ./dockerfiles/build/src/
