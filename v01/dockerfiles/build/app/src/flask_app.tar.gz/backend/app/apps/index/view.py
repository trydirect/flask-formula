from flask import render_template
from app.libs.controllers import Resource


class Index(Resource):
    def get(self):
        return render_template('index.html')

