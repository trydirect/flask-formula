from flask_restful import fields

DemoSchema = {
    'number': fields.Integer,
}