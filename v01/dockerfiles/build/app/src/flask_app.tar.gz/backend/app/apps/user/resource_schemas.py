from flask_restful import fields

CustomerSchema = {
    'auth_token': fields.String
}