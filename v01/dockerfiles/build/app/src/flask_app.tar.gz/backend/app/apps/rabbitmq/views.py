from app.libs.controllers import Resource
import pika
from flask import current_app


class RabbitMQSent(Resource):
        def get(self):
            port = 5672
            credentials = pika.PlainCredentials("guest", "guest")
            params = pika.ConnectionParameters(host="mq", port=port, credentials=credentials)
            connection = pika.BlockingConnection(params)
            channel = connection.channel()

            channel.queue_declare(queue='hello')

            channel.basic_publish(exchange='',
                                  routing_key='hello',
                                  body='Hello World!')

            connection.close()
            return "Sent 'Hello World!'"


class RabbitMQReceive(Resource):
    def get(self):
        port = 5672

        credentials = pika.PlainCredentials("guest", "guest")
        params = pika.ConnectionParameters(host="mq", port=port, credentials=credentials)
        connection = pika.BlockingConnection(params)
        channel = connection.channel()

        channel.queue_declare(queue='hello')

        def callback(ch, meimportthod, properties, body):
            return "Received %r" % body

        channel.basic_consume(
            callback,
            queue='hello',
            no_ack=True
        )

        print('Waiting for messages.')
        channel.start_consuming()