from app.libs.controllers import Resource
import hvac, os


class VaultTest(Resource):
    def get(self):
        vault_url = os.environ['VAULT_URL']
        vault_token = os.environ['VAULT_TOKEN']
        client = hvac.Client(url=vault_url, token=vault_token)
        if client.is_authenticated() is True:
            client.write('secret/test', test='test')
            return {
                'success': True,
                'response': client.read('secret/test')
            }
        else:
            raise hvac.exceptions.Unauthorized()
