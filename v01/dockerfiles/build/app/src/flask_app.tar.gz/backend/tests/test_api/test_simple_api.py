import requests

url_base = 'http://localhost:8000/api/v1'


def test_redis_api():
    response = requests.get('{}/redis'.format(url_base))
    assert response.status_code == 200
    assert response.text in 'response' and response.text['success']


def test_hello_api():
    response = requests.get('{}/hello'.format(url_base))
    assert response.status_code == 200
    assert response.text == 'Hello World!'


def test_vault_api():
    response = requests.get('{}/vault'.format(url_base))
    assert response.status_code == 200
    assert response.text['response'] is None
