import docker
import pytest
from pathlib import Path
from ..utils import (
    display_detail_container
)

client = docker.from_env()


def test_containers():
    for container in client.containers.list():
        display_detail_container(container)
    assert True


def test_containers_status():
    for container in client.containers.list():
        assert container.status == 'running'


@pytest.mark.parametrize("dockerfile", "Dockerfile")
def test_env_vars_1(dockerfile):
    tag = "app"
    test_path = Path(__file__)
    path = test_path.parent / ""
    client.images.build(path=str(path), dockerfile=dockerfile, tag=tag)
    container = client.containers.run(
        tag, name='test', ports={"80": "8000"}, detach=True
    )
