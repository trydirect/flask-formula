from docker.errors import NotFound


def remove_previous_container(client, container):
    try:
        previous = client.containers.get(container_id=container.name)
        previous.stop()
        previous.remove()
    except NotFound:
        return None


def display_detail_container(container):
    print('\n')
    print('Name container: {}'.format(container.name))
    print('ID container: {}'.format(container.short_id))
    print('Image container: {}'.format(container.image))
    print('Status container: {}'.format(container.status))
    print('==========================================================')