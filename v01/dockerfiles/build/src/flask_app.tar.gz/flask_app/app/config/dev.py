"""
dev environment configuration
"""
from app.config import DefaultConfig
import os


class Config(DefaultConfig):
    API_DOMAIN_NAME = 'auto.optimum-web.com'
    DOMAIN_NAME = 'auto.optimum-web.com'
    PROTOCOL = 'http'
    DEBUG = True
    TESTING = True
    SQLALCHEMY_DATABASE_URI = 'postgresql://{user}:{passw}@{host}/{name}'.format(
        user=os.environ.get('PGSQL_USER'),
        passw=os.environ.get('PGSQL_PASSWORD'),
        name=os.environ.get('PGSQL_DATABASE'),
        host=os.environ.get('PGSQL_HOST'),
    )

    RABBITMQ_HOST = 'rabbit'
    RABBITMQ_USER = os.environ.get('RABBITMQ_DEFAULT_USER')
    RABBITMQ_PASSWORD = os.environ.get('RABBITMQ_DEFAULT_PASS')